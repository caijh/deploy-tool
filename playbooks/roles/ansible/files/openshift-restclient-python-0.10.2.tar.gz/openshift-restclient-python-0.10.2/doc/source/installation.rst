============
Installation
============

At the command line::

    $ pip install openshift

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv openshift
    $ pip install openshift
