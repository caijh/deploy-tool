========
Usage
========

To use openshift-restclient-python in a project::

    import openshift
